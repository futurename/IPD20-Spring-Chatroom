package com.chatroom.ipd20;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ipd20ApplicationTests {

	@Test
	void contextLoads() {
	}

}
